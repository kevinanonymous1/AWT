All practicals for FYMCA AWT 

![image](https://github.com/user-attachments/assets/a7c3597b-f5c6-487d-9e51-2f1523ea0d8d)
